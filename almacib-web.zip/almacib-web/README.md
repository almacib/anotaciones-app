# 🔍 ALMACIB Web

ALMACIB es una herramienta OSINT con interfaz web hecha en Flask.  
Se recomienda su uso únicamente con fines **educativos y éticos**.

## 🚀 Ejecución local

```bash
pip install -r requirements.txt
python almacib_web.py
```

Disponible en: [http://127.0.0.1:8000](http://127.0.0.1:8000)

## ☁️ Despliegue en Render

1. Haz fork de este repo en GitHub.
2. Ve a [Render](https://render.com) → New → Web Service.
3. Conecta tu repo y selecciona branch `main`.
4. Render detecta `requirements.txt` + `Procfile`.
5. Te dará una URL tipo `https://almacib.onrender.com`.

## ☁️ Despliegue en Railway

1. Haz fork en GitHub.
2. Ve a [Railway](https://railway.app) → New Project → Deploy from Repo.
3. Railway instala dependencias y arranca con `Procfile`.
4. Te dará una URL pública con HTTPS.

## ⚠️ Disclaimer

Esta herramienta es solo para fines educativos y de investigación ética.  
El usuario es responsable del uso que haga de esta herramienta.  
Respeta las leyes de privacidad y los términos de servicio de los sitios consultados.
