#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALMACIB WEB - Todo en Uno
Herramienta OSINT con interfaz web
Uso educativo y ético solamente
"""

from flask import Flask, request, redirect, url_for, render_template_string
import sys
import os
import re
import json
import time
import socket
import requests
from datetime import datetime
from typing import Dict, List, Optional
from urllib.parse import quote_plus
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
import traceback

# ============================================================================
# CONFIGURACIÓN OSINT
# ============================================================================

class OSINTConfig:
    """Configuration for OSINT searches"""

    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
    }

    TIMEOUT = 10
    MAX_RETRIES = 3

    # Username search platforms
    USERNAME_SITES = {
        'GitHub': 'https://github.com/{}',
        'Twitter': 'https://twitter.com/{}',
        'Instagram': 'https://instagram.com/{}',
        'Reddit': 'https://reddit.com/user/{}',
        'LinkedIn': 'https://linkedin.com/in/{}',
        'Facebook': 'https://facebook.com/{}',
        'TikTok': 'https://tiktok.com/@{}',
        'YouTube': 'https://youtube.com/@{}',
        'Twitch': 'https://twitch.tv/{}',
        'Pinterest': 'https://pinterest.com/{}',
        'Telegram': 'https://t.me/{}',
        'Medium': 'https://medium.com/@{}',
        'DeviantArt': 'https://{}.deviantart.com',
        'Behance': 'https://behance.net/{}',
        'Dribbble': 'https://dribbble.com/{}',
        'Patreon': 'https://patreon.com/{}',
        'Spotify': 'https://open.spotify.com/user/{}',
        'SoundCloud': 'https://soundcloud.com/{}',
        'Vimeo': 'https://vimeo.com/{}',
        'Flickr': 'https://flickr.com/people/{}',
        'GitLab': 'https://gitlab.com/{}',
        'Bitbucket': 'https://bitbucket.org/{}',
        'StackOverflow': 'https://stackoverflow.com/users/{}',
        'HackerNews': 'https://news.ycombinator.com/user?id={}',
        'Keybase': 'https://keybase.io/{}',
        'About.me': 'https://about.me/{}',
        'Linktree': 'https://linktr.ee/{}',
        'Cash.app': 'https://cash.app/${}',
        'Venmo': 'https://venmo.com/{}',
        'Roblox': 'https://roblox.com/user.aspx?username={}',
        'Steam': 'https://steamcommunity.com/id/{}',
        'Discord': 'https://discord.com/users/{}',
        'Snapchat': 'https://snapchat.com/add/{}',
        'WhatsApp': 'https://wa.me/{}',
        'Tumblr': 'https://{}.tumblr.com',
        'WordPress': 'https://{}.wordpress.com',
        'Blogger': 'https://{}.blogspot.com',
        'Quora': 'https://quora.com/profile/{}',
        'Goodreads': 'https://goodreads.com/{}',
        'Etsy': 'https://etsy.com/shop/{}',
        'Fiverr': 'https://fiverr.com/{}',
        'Upwork': 'https://upwork.com/freelancers/~{}',
    }

# ============================================================================
# MOTOR OSINT
# ============================================================================

class OSINTSearcher:
    """Main OSINT search engine"""

    def __init__(self, use_tor: bool = False):
        self.use_tor = use_tor
        self.session = requests.Session()
        self.session.headers.update(OSINTConfig.HEADERS)

        if use_tor:
            self.session.proxies = {
                'http': 'socks5h://127.0.0.1:9050',
                'https': 'socks5h://127.0.0.1:9050'
            }

    def check_url(self, url: str) -> bool:
        """Check if URL exists"""
        try:
            response = self.session.get(url, timeout=OSINTConfig.TIMEOUT, allow_redirects=True)
            return response.status_code == 200
        except:
            return False

    def search_username(self, username: str) -> Dict[str, bool]:
        """Search username across multiple platforms"""
        results = {}

        for platform, url_template in OSINTConfig.USERNAME_SITES.items():
            url = url_template.format(username)
            results[platform] = self.check_url(url)
            time.sleep(0.05)  # Rate limiting

        return results

    def search_email(self, email: str) -> Dict[str, any]:
        """Enhanced email OSINT search"""
        results = {
            'email': email,
            'gravatar': None,
            'breach_check': [],
            'paste_sites': [],
            'social_media': [],
            'dorks': []
        }

        # Gravatar check
        try:
            import hashlib
            email_hash = hashlib.md5(email.lower().encode()).hexdigest()
            gravatar_url = f"https://www.gravatar.com/avatar/{email_hash}?d=404"
            if self.check_url(gravatar_url):
                results['gravatar'] = f"https://www.gravatar.com/{email_hash}"
        except:
            pass

        # Public breach databases (free sources)
        breach_sites = {
            'Have I Been Pwned': f"https://haveibeenpwned.com/account/{quote_plus(email)}",
            'DeHashed': f"https://dehashed.com/search?query={quote_plus(email)}",
            'LeakCheck': f"https://leakcheck.io/search?query={quote_plus(email)}",
            'IntelligenceX': f"https://intelx.io/?s={quote_plus(email)}",
            'Snusbase': f"https://snusbase.com/search/{quote_plus(email)}",
        }

        for site, url in breach_sites.items():
            results['breach_check'].append({
                'site': site,
                'url': url,
                'note': 'Manual verification required'
            })

        # Paste sites
        paste_sites = {
            'Pastebin': f"https://psbdmp.ws/?q={quote_plus(email)}",
            'Ghostbin': f"https://ghostbin.com/search?q={quote_plus(email)}",
            'Slexy': f"https://slexy.org/search?q={quote_plus(email)}",
            'Justpaste.it': f"https://justpaste.it/search?q={quote_plus(email)}",
        }

        for site, url in paste_sites.items():
            results['paste_sites'].append({
                'site': site,
                'url': url
            })

        # Social media email search
        social_searches = {
            'Google': f"https://www.google.com/search?q={quote_plus(email)}",
            'DuckDuckGo': f"https://duckduckgo.com/?q={quote_plus(email)}",
            'Bing': f"https://www.bing.com/search?q={quote_plus(email)}",
        }

        for engine, url in social_searches.items():
            results['social_media'].append({
                'engine': engine,
                'url': url
            })

        # Advanced Google Dorks
        dorks = [
            f'"{email}"',
            f'"{email}" site:linkedin.com',
            f'"{email}" site:facebook.com',
            f'"{email}" site:twitter.com',
            f'"{email}" site:instagram.com',
            f'"{email}" site:github.com',
            f'"{email}" filetype:pdf',
            f'"{email}" filetype:doc',
            f'"{email}" filetype:xls',
            f'"{email}" "password"',
            f'"{email}" "leaked"',
            f'"{email}" "database"',
            f'"{email}" site:pastebin.com',
            f'"{email}" inurl:admin',
            f'"{email}" inurl:login',
        ]

        for dork in dorks:
            results['dorks'].append({
                'dork': dork,
                'google_url': f"https://www.google.com/search?q={quote_plus(dork)}",
                'duckduckgo_url': f"https://duckduckgo.com/?q={quote_plus(dork)}"
            })

        return results

    def search_phone(self, phone: str) -> Dict[str, any]:
        """Enhanced phone number OSINT"""
        results = {
            'phone': phone,
            'formatted': None,
            'valid': False,
            'country': None,
            'carrier': None,
            'timezone': None,
            'type': None,
            'truecaller': None,
            'search_links': []
        }

        try:
            parsed = phonenumbers.parse(phone, None)
            results['valid'] = phonenumbers.is_valid_number(parsed)
            results['formatted'] = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
            results['country'] = geocoder.description_for_number(parsed, 'en')
            results['carrier'] = carrier.name_for_number(parsed, 'en')
            results['timezone'] = timezone.time_zones_for_number(parsed)

            number_type = phonenumbers.number_type(parsed)
            type_map = {
                0: 'Fixed Line',
                1: 'Mobile',
                2: 'Fixed Line or Mobile',
                3: 'Toll Free',
                4: 'Premium Rate',
                5: 'Shared Cost',
                6: 'VoIP',
                7: 'Personal Number',
                8: 'Pager',
                9: 'UAN',
                10: 'Voicemail',
                27: 'Unknown'
            }
            results['type'] = type_map.get(number_type, 'Unknown')

        except Exception as e:
            results['error'] = str(e)

        # Truecaller integration
        phone_clean = re.sub(r'\D', '', phone)
        results['truecaller'] = f"https://www.truecaller.com/search/in/{phone_clean}"

        # Search links
        search_sites = {
            'Truecaller': f"https://www.truecaller.com/search/in/{phone_clean}",
            'NumLookup': f"https://www.numlookup.com/?phone={phone_clean}",
            'WhitePages': f"https://www.whitepages.com/phone/{phone_clean}",
            'ThatsThem': f"https://thatsthem.com/phone/{phone_clean}",
            'Spy Dialer': f"https://www.spydialer.com/default.aspx?SearchType=1&Number={phone_clean}",
            'CallerID Test': f"https://www.calleridtest.com/?number={phone_clean}",
            'Google': f"https://www.google.com/search?q={quote_plus(phone)}",
            'Facebook': f"https://www.facebook.com/search/top/?q={quote_plus(phone)}",
            'LinkedIn': f"https://www.linkedin.com/search/results/all/?keywords={quote_plus(phone)}",
        }

        for site, url in search_sites.items():
            results['search_links'].append({
                'site': site,
                'url': url
            })

        return results

    def search_ip(self, ip: str) -> Dict[str, any]:
        """IP address OSINT"""
        results = {
            'ip': ip,
            'hostname': None,
            'geolocation': {},
            'reputation': [],
            'whois': None
        }

        # Hostname lookup
        try:
            results['hostname'] = socket.gethostbyaddr(ip)[0]
        except:
            results['hostname'] = 'N/A'

        # Geolocation (using free API)
        try:
            response = self.session.get(f"http://ip-api.com/json/{ip}", timeout=OSINTConfig.TIMEOUT)
            if response.status_code == 200:
                results['geolocation'] = response.json()
        except:
            pass

        # Reputation checks
        reputation_sites = {
            'AbuseIPDB': f"https://www.abuseipdb.com/check/{ip}",
            'VirusTotal': f"https://www.virustotal.com/gui/ip-address/{ip}",
            'Shodan': f"https://www.shodan.io/host/{ip}",
            'Censys': f"https://search.censys.io/hosts/{ip}",
            'IPVoid': f"https://www.ipvoid.com/ip-blacklist-check/?ip={ip}",
            'ThreatCrowd': f"https://www.threatcrowd.org/ip.php?ip={ip}",
            'AlienVault': f"https://otx.alienvault.com/indicator/ip/{ip}",
            'GreyNoise': f"https://www.greynoise.io/viz/ip/{ip}",
            'IPInfo': f"https://ipinfo.io/{ip}",
        }

        for site, url in reputation_sites.items():
            results['reputation'].append({
                'site': site,
                'url': url
            })

        # WHOIS
        results['whois'] = f"https://who.is/whois-ip/ip-address/{ip}"

        return results

# ============================================================================
# APLICACIÓN WEB FLASK
# ============================================================================

app = Flask(__name__)
searcher = OSINTSearcher(use_tor=False)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>ALMACIB Web - OSINT Tool</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      text-align: center;
    }
    .header h1 {
      font-size: 2.5em;
      margin-bottom: 10px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    .header p {
      font-size: 1.1em;
      opacity: 0.9;
    }
    .content {
      padding: 30px;
    }
    .search-section {
      background: #f8f9fa;
      border-radius: 10px;
      padding: 25px;
      margin-bottom: 25px;
      border-left: 5px solid #667eea;
    }
    .search-section h2 {
      color: #667eea;
      margin-bottom: 15px;
      font-size: 1.5em;
    }
    .search-form {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
    .search-form input {
      flex: 1;
      min-width: 250px;
      padding: 12px 15px;
      border: 2px solid #ddd;
      border-radius: 8px;
      font-size: 1em;
      transition: border-color 0.3s;
    }
    .search-form input:focus {
      outline: none;
      border-color: #667eea;
    }
    .search-form button {
      padding: 12px 30px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 1em;
      font-weight: bold;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    .search-form button:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    .results {
      margin-top: 30px;
    }
    .results h3 {
      color: #333;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 3px solid #667eea;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      background: white;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    table thead {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }
    table th, table td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }
    table tr:hover {
      background: #f8f9fa;
    }
    .badge {
      display: inline-block;
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 0.85em;
      font-weight: bold;
    }
    .badge-success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .badge-danger {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    .info-box {
      background: #e7f3ff;
      border-left: 4px solid #2196F3;
      padding: 15px;
      margin: 15px 0;
      border-radius: 5px;
    }
    .link-list {
      list-style: none;
      padding: 0;
    }
    .link-list li {
      padding: 10px;
      margin: 5px 0;
      background: #f8f9fa;
      border-radius: 5px;
      transition: background 0.2s;
    }
    .link-list li:hover {
      background: #e9ecef;
    }
    .link-list a {
      color: #667eea;
      text-decoration: none;
      font-weight: 500;
    }
    .link-list a:hover {
      text-decoration: underline;
    }
    .error {
      background: #f8d7da;
      color: #721c24;
      padding: 15px;
      border-radius: 8px;
      border-left: 4px solid #f5c6cb;
      margin: 20px 0;
    }
    .dork-item {
      background: #fff3cd;
      padding: 12px;
      margin: 8px 0;
      border-radius: 5px;
      border-left: 3px solid #ffc107;
    }
    .dork-item code {
      background: #fff;
      padding: 3px 8px;
      border-radius: 3px;
      font-family: 'Courier New', monospace;
      color: #d63384;
    }
    .summary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 20px;
      border-radius: 10px;
      margin: 20px 0;
      text-align: center;
      font-size: 1.2em;
      font-weight: bold;
    }
    @media (max-width: 768px) {
      .header h1 { font-size: 1.8em; }
      .search-form { flex-direction: column; }
      .search-form input, .search-form button { width: 100%; }
      table { font-size: 0.9em; }
      table th, table td { padding: 10px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🔍 ALMACIB WEB</h1>
      <p>Advanced OSINT Intelligence Tool | Uso Educativo y Ético</p>
    </div>

    <div class="content">
      <!-- USERNAME SEARCH -->
      <div class="search-section">
        <h2>👤 Búsqueda de Username</h2>
        <form method="get" action="{{ url_for('username') }}" class="search-form">
          <input type="text" name="q" placeholder="Ingresa un username..." value="{{ request.args.get('q','') }}" required>
          <button type="submit">🔍 Buscar</button>
        </form>
      </div>

      {% if username_results is not none %}
      <div class="results">
        <h3>Resultados para: {{ username_query }}</h3>
        <table>
          <thead>
            <tr>
              <th>Plataforma</th>
              <th>Estado</th>
              <th>URL</th>
            </tr>
          </thead>
          <tbody>
            {% for platform, found in username_results.items() %}
            <tr>
              <td><strong>{{ platform }}</strong></td>
              <td>
                {% if found %}
                  <span class="badge badge-success">✅ Encontrado</span>
                {% else %}
                  <span class="badge badge-danger">❌ No encontrado</span>
                {% endif %}
              </td>
              <td>
                {% set url = username_sites[platform].format(username_query) %}
                {% if found %}
                  <a href="{{ url }}" target="_blank" rel="noopener">{{ url }}</a>
                {% else %}
                  <span style="color: #999;">{{ url }}</span>
                {% endif %}
              </td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
        <div class="summary">
          📊 Encontrados: {{ username_found }}/{{ username_total }} perfiles
        </div>
      </div>
      {% endif %}

      <!-- EMAIL SEARCH -->
      <div class="search-section">
        <h2>📧 Email OSINT</h2>
        <form method="get" action="{{ url_for('email') }}" class="search-form">
          <input type="email" name="q" placeholder="email@ejemplo.com" value="{{ request.args.get('q','') }}" required>
          <button type="submit">🔍 Buscar</button>
        </form>
      </div>

      {% if email_results is not none %}
      <div class="results">
        <h3>Resultados para: {{ email_results.email }}</h3>

        {% if email_results.gravatar %}
        <div class="info-box">
          <strong>🖼️ Gravatar encontrado:</strong> 
          <a href="{{ email_results.gravatar }}" target="_blank">{{ email_results.gravatar }}</a>
        </div>
        {% endif %}

        <h4 style="margin-top: 25px; color: #667eea;">🔓 Bases de Datos de Brechas</h4>
        <ul class="link-list">
          {% for b in email_results.breach_check %}
            <li>🔗 <a href="{{ b.url }}" target="_blank" rel="noopener">{{ b.site }}</a></li>
          {% endfor %}
        </ul>

        <h4 style="margin-top: 25px; color: #667eea;">📋 Sitios de Pastes</h4>
        <ul class="link-list">
          {% for p in email_results.paste_sites %}
            <li>🔗 <a href="{{ p.url }}" target="_blank" rel="noopener">{{ p.site }}</a></li>
          {% endfor %}
        </ul>

        <h4 style="margin-top: 25px; color: #667eea;">🎯 Top 5 Google Dorks</h4>
        {% for d in email_results.dorks[:5] %}
        <div class="dork-item">
          <code>{{ d.dork }}</code><br>
          <small>
            <a href="{{ d.google_url }}" target="_blank" rel="noopener">🔍 Google</a> | 
            <a href="{{ d.duckduckgo_url }}" target="_blank" rel="noopener">🦆 DuckDuckGo</a>
          </small>
        </div>
        {% endfor %}
      </div>
      {% endif %}

      <!-- PHONE SEARCH -->
      <div class="search-section">
        <h2>📱 Phone Number Lookup</h2>
        <form method="get" action="{{ url_for('phone') }}" class="search-form">
          <input type="text" name="q" placeholder="+34123456789" value="{{ request.args.get('q','') }}" required>
          <button type="submit">🔍 Buscar</button>
        </form>
      </div>

      {% if phone_results is not none %}
      <div class="results">
        <h3>Resultados para: {{ phone_query }}</h3>

        <table>
          <tbody>
            <tr>
              <td><strong>Válido</strong></td>
              <td>{{ "✅ Sí" if phone_results.valid else "❌ No" }}</td>
            </tr>
            {% if phone_results.formatted %}
            <tr>
              <td><strong>Formateado</strong></td>
              <td>{{ phone_results.formatted }}</td>
            </tr>
            {% endif %}
            {% if phone_results.country %}
            <tr>
              <td><strong>País</strong></td>
              <td>{{ phone_results.country }}</td>
            </tr>
            {% endif %}
            {% if phone_results.carrier %}
            <tr>
              <td><strong>Operador</strong></td>
              <td>{{ phone_results.carrier }}</td>
            </tr>
            {% endif %}
            {% if phone_results.type %}
            <tr>
              <td><strong>Tipo</strong></td>
              <td>{{ phone_results.type }}</td>
            </tr>
            {% endif %}
            {% if phone_results.timezone %}
            <tr>
              <td><strong>Zona Horaria</strong></td>
              <td>{{ ", ".join(phone_results.timezone) }}</td>
            </tr>
            {% endif %}
          </tbody>
        </table>

        {% if phone_results.truecaller %}
        <div class="info-box">
          <strong>📞 Truecaller:</strong> 
          <a href="{{ phone_results.truecaller }}" target="_blank">{{ phone_results.truecaller }}</a>
        </div>
        {% endif %}

        <h4 style="margin-top: 25px; color: #667eea;">🔗 Enlaces de Búsqueda</h4>
        <ul class="link-list">
          {% for l in phone_results.search_links %}
            <li>🔗 <a href="{{ l.url }}" target="_blank" rel="noopener">{{ l.site }}</a></li>
          {% endfor %}
        </ul>
      </div>
      {% endif %}

      <!-- IP SEARCH -->
      <div class="search-section">
        <h2>🌐 IP Address Investigation</h2>
        <form method="get" action="{{ url_for('ip') }}" class="search-form">
          <input type="text" name="q" placeholder="8.8.8.8" value="{{ request.args.get('q','') }}" required>
          <button type="submit">🔍 Buscar</button>
        </form>
      </div>

      {% if ip_results is not none %}
      <div class="results">
        <h3>Resultados para: {{ ip_results.ip }}</h3>

        <table>
          <tbody>
            <tr>
              <td><strong>IP Address</strong></td>
              <td>{{ ip_results.ip }}</td>
            </tr>
            <tr>
              <td><strong>Hostname</strong></td>
              <td>{{ ip_results.hostname }}</td>
            </tr>
            {% if ip_results.geolocation %}
              {% set geo = ip_results.geolocation %}
              {% if geo.country %}
              <tr>
                <td><strong>País</strong></td>
                <td>{{ geo.country }} ({{ geo.countryCode }})</td>
              </tr>
              {% endif %}
              {% if geo.city %}
              <tr>
                <td><strong>Ciudad</strong></td>
                <td>{{ geo.city }}</td>
              </tr>
              {% endif %}
              {% if geo.isp %}
              <tr>
                <td><strong>ISP</strong></td>
                <td>{{ geo.isp }}</td>
              </tr>
              {% endif %}
              {% if geo.org %}
              <tr>
                <td><strong>Organización</strong></td>
                <td>{{ geo.org }}</td>
              </tr>
              {% endif %}
              {% if geo.as %}
              <tr>
                <td><strong>AS</strong></td>
                <td>{{ geo.as }}</td>
              </tr>
              {% endif %}
            {% endif %}
          </tbody>
        </table>

        <h4 style="margin-top: 25px; color: #667eea;">🛡️ Reputación y Threat Intelligence</h4>
        <ul class="link-list">
          {% for r in ip_results.reputation %}
            <li>🔗 <a href="{{ r.url }}" target="_blank" rel="noopener">{{ r.site }}</a></li>
          {% endfor %}
        </ul>

        {% if ip_results.whois %}
        <div class="info-box">
          <strong>📋 WHOIS:</strong> 
          <a href="{{ ip_results.whois }}" target="_blank">{{ ip_results.whois }}</a>
        </div>
        {% endif %}
      </div>
      {% endif %}

      {% if error %}
      <div class="error">
        <h4>❌ Error</h4>
        <pre>{{ error }}</pre>
      </div>
      {% endif %}
    </div>
  </div>
</body>
</html>
"""

class SimpleNamespace(dict):
    """Utility to pass dicts as objects to template"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__dict__ = self

def render_page(extra_ctx=None):
    """Render main page with optional context"""
    ctx = dict(
        username_results=None,
        username_sites=OSINTConfig.USERNAME_SITES,
        username_query="",
        username_found=0,
        username_total=0,
        email_results=None,
        phone_results=None,
        phone_query="",
        ip_results=None,
        error=None,
    )
    if extra_ctx:
        ctx.update(extra_ctx)
    return render_template_string(HTML_TEMPLATE, **ctx)

@app.route("/")
def index():
    """Home page"""
    return render_page()

@app.route("/username")
def username():
    """Username search endpoint"""
    q = request.args.get("q", "").strip()
    if not q:
        return redirect(url_for("index"))
    try:
        results = searcher.search_username(q)
        found_count = sum(1 for v in results.values() if v)
        total_count = len(results)
        return render_page(dict(
            username_results=results,
            username_sites=OSINTConfig.USERNAME_SITES,
            username_query=q,
            username_found=found_count,
            username_total=total_count
        ))
    except Exception as e:
        return render_page(dict(error=traceback.format_exc()))

@app.route("/email")
def email():
    """Email search endpoint"""
    q = request.args.get("q", "").strip()
    if not q:
        return redirect(url_for("index"))
    if not re.match(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$', q):
        return render_page(dict(error="Formato de email inválido."))
    try:
        results = searcher.search_email(q)
        return render_page(dict(email_results=SimpleNamespace(**results)))
    except Exception:
        return render_page(dict(error=traceback.format_exc()))

@app.route("/phone")
def phone():
    """Phone search endpoint"""
    q = request.args.get("q", "").strip()
    if not q:
        return redirect(url_for("index"))
    try:
        results = searcher.search_phone(q)
        return render_page(dict(
            phone_results=SimpleNamespace(**results),
            phone_query=q
        ))
    except Exception:
        return render_page(dict(error=traceback.format_exc()))

@app.route("/ip")
def ip():
    """IP search endpoint"""
    q = request.args.get("q", "").strip()
    if not q:
        return redirect(url_for("index"))
    if not re.match(r'^\d{1,3}(\.\d{1,3}){3}$', q):
        return render_page(dict(error="Formato de IP inválido. Solo IPv4."))
    try:
        results = searcher.search_ip(q)
        return render_page(dict(ip_results=SimpleNamespace(**results)))
    except Exception:
        return render_page(dict(error=traceback.format_exc()))

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║                                                           ║
    ║     █████╗ ██╗     ███╗   ███╗ █████╗  ██████╗██╗██████╗ ║
    ║    ██╔══██╗██║     ████╗ ████║██╔══██╗██╔════╝██║██╔══██╗║
    ║    ███████║██║     ██╔████╔██║███████║██║     ██║██████╔╝║
    ║    ██╔══██║██║     ██║╚██╔╝██║██╔══██║██║     ██║██╔══██╗║
    ║    ██║  ██║███████╗██║ ╚═╝ ██║██║  ██║╚██████╗██║██████╔╝║
    ║    ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝╚═════╝ ║
    ║                                                           ║
    ║              ALMACIB WEB - OSINT Tool v2.0                ║
    ║                  Servidor Web Iniciado                    ║
    ╚═══════════════════════════════════════════════════════════╝

    🌐 Servidor corriendo en: http://127.0.0.1:8000
    📱 Acceso desde red local: http://TU_IP:8000

    ⚠️  DISCLAIMER: Uso educativo y ético solamente.
        Respeta las leyes de privacidad y términos de servicio.

    Presiona Ctrl+C para detener el servidor.
    """)

    # Para producción, usa: waitress-serve --listen=0.0.0.0:$PORT almacib_web:app
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port, debug=False)
